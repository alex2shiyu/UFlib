Chuang Chen Vim settings
